/* MEV Bot Pro - Main Script */

// ── FAQ ACCORDION ──
document.querySelectorAll('.faq-question').forEach(function(btn) {
  btn.addEventListener('click', function() {
    var item = this.closest('.faq-item');
    var isOpen = item.classList.contains('open');

    // Close all
    document.querySelectorAll('.faq-item.open').forEach(function(el) {
      el.classList.remove('open');
    });

    // Open clicked if it was closed
    if (!isOpen) {
      item.classList.add('open');
    }
  });
});

// ── MOBILE NAV TOGGLE ──
var hamburger = document.getElementById('hamburger');
var mobileNav = document.getElementById('mobile-nav');

if (hamburger && mobileNav) {
  hamburger.addEventListener('click', function() {
    mobileNav.classList.toggle('open');
  });

  // Close when clicking a link
  mobileNav.querySelectorAll('a').forEach(function(link) {
    link.addEventListener('click', function() {
      mobileNav.classList.remove('open');
    });
  });
}

// ── STICKY HEADER SHADOW ──
window.addEventListener('scroll', function() {
  var header = document.querySelector('header');
  if (header) {
    if (window.scrollY > 10) {
      header.style.boxShadow = '0 2px 20px rgba(0,0,0,0.4)';
    } else {
      header.style.boxShadow = 'none';
    }
  }
});
